from mpf.core.mode import Mode
from mpf.core.delays import DelayManager
from modes.common.case_file_mixin import CaseFileMixin

import random


class Pardo(CaseFileMixin, Mode):
    """Pardo: Hypnosis Reel.

    Hypnosis Reel choice puzzle.
    Each round lights three identical-looking choices. The spinner briefly
    reveals the real shot. The first wrong choice is removed and reduces the
    Jackpot; a second wrong choice ends that round. Four correct rounds defeat
    Pardo before the available rounds expire.
    """

    BASE_ROUNDS = 4
    EXTRA_ROUNDS = 2
    CORRECT_SHOTS_TO_WIN = 4

    BASE_JACKPOT_VALUES = (200_000, 300_000, 400_000, 500_000)
    BIGGER_JACKPOT_VALUES = (300_000, 450_000, 600_000, 750_000)
    JACKPOT_MISS_PENALTY = 100_000
    BIGGER_JACKPOT_MISS_PENALTY = 150_000
    BAD_SHOT_SCORE = 20_000

    NORMAL_REVEAL_MS = 4_000
    MORE_TIME_REVEAL_MS = 6_000
    REVEAL_FLASH_INTERVAL_MS = 250
    RESULT_GI_FLASH_MS = 350

    SHOT_GROUPS = [
        "left_web",
        "center_web",
        "upper_targets",
        "left_drops",
        "right_drops",
        "pop_left",
        "pop_right",
    ]

    UPPER_GROUPS = {"upper_targets"}

    def mode_start(self, **kwargs):
        super().mode_start(**kwargs)
        self.reset_active_mode_summary(stat_count=3)

        self.delay = DelayManager(self.machine)
        self.mode_done = False
        self.round_number = 0
        self.rounds_to_play = self.BASE_ROUNDS
        self.correct_shots = 0
        self.incorrect_shots = 0
        self.first_guess_jps = 0
        self.second_guess_jps = 0
        self.round_awarding = False
        self.mode_points = 0
        self.current_groups = []
        self.correct_group = None
        self.first_round_all_good = False
        self.reveal_flash_on = False
        self.reveal_ms = self.NORMAL_REVEAL_MS
        self.jackpot_values = self.BASE_JACKPOT_VALUES
        self.jackpot_miss_penalty = self.JACKPOT_MISS_PENALTY
        self.jackpot_value = self.jackpot_values[0]
        self.wrong_this_round = 0

        self.case_files = self.get_case_file_bonuses()
        self._apply_case_file_bonuses()
        self.publish_case_file_bonus_events("pardo")
        self.publish_active_case_file_helpers([
            ("more_jackpots", "TWO EXTRA HYPNOSIS ROUNDS"),
            ("bigger_jackpots", "BIGGER HYPNOSIS JACKPOTS"),
            ("more_time", "LONGER SPINNER REVEAL"),
            ("safety_net", "10 SECOND BALL SAVE ACTIVE"),
            ("shot_assist", "FIRST ROUND ALL GOOD"),
        ])

        for group in self.SHOT_GROUPS:
            self.add_mode_event_handler(f"pardo_{group}_hit", self._shot_hit, group=group)

        self.add_mode_event_handler("pardo_spinner_reveal", self._reveal_current_round)
        self.add_mode_event_handler("pardo_spinner_switch", self._spinner_switch)
        self.add_mode_event_handler("pardo_complete_request", self._complete_mode)
        self.add_mode_event_handler("pardo_fail_request", self._fail_mode)

        self.machine.game.player["pardo_state"] = 1
        self._sync_player_vars()
        self.machine.events.post("pardo_startup_complete")
        self.machine.events.post("show_mode_message_long", message_mode_title="PARDO", message_mode_subtitle="BREAK THE HYPNOSIS")
        self._start_next_round()

    def mode_stop(self, **kwargs):
        self.machine.events.post("hide_mode_status")
        self.delay.remove("pardo_hide_reveal")
        self.delay.remove("pardo_reveal_flash")
        self.delay.remove("pardo_result_gi_restore")
        self.machine.events.post("pardo_all_lights_off")
        self.machine.events.post("rooftop_diverter_close")
        self.clear_active_case_file_helpers()
        # Catch-all: no delayed villain/wizard callback may survive into bonus.
        self.delay.clear()
        super().mode_stop(**kwargs)

    def _apply_case_file_bonuses(self):
        if self.has_case_file("more_jackpots"):
            self.rounds_to_play += self.EXTRA_ROUNDS

        if self.has_case_file("bigger_jackpots"):
            self.jackpot_values = self.BIGGER_JACKPOT_VALUES
            self.jackpot_miss_penalty = self.BIGGER_JACKPOT_MISS_PENALTY
            self.jackpot_value = self.jackpot_values[0]

        if self.has_case_file("more_time"):
            self.reveal_ms = self.MORE_TIME_REVEAL_MS

        if self.has_case_file("safety_net"):
            self.machine.events.post("start_case_file_ball_save")

        if self.has_case_file("shot_assist"):
            self.first_round_all_good = True

    def _spinner_switch(self, **kwargs):
        if self._inactive():
            return
        self._reveal_current_round()

    def _start_next_round(self):
        self.round_awarding = False
        if self._inactive():
            return

        self.delay.remove("pardo_hide_reveal")

        if self.round_number >= self.rounds_to_play:
            self._fail_mode()
            return

        self.round_number += 1
        self.current_groups = random.sample(self.SHOT_GROUPS, 3)
        self.correct_group = random.choice(self.current_groups)
        self.wrong_this_round = 0
        value_index = min(self.round_number - 1, len(self.jackpot_values) - 1)
        self.jackpot_value = self.jackpot_values[value_index]

        self._sync_player_vars()
        self.machine.events.post(
            "pardo_round_started",
            round=self.round_number,
            total_rounds=self.rounds_to_play,
            jackpot=self.jackpot_value,
            incorrect=self.incorrect_shots,
        )
        self.machine.events.post("show_mode_message", message_mode_title="HYPNOSIS REEL", message_mode_subtitle="SPIN TO REVEAL", message_mode_value=self.jackpot_value)
        self._show_hidden_round()
        self._update_rooftop_diverter()

    def _shot_hit(self, group=None, **kwargs):
        if self.round_awarding:
            return

        if self._inactive() or group not in self.current_groups:
            return

        all_good = self.first_round_all_good and self.round_number == 1
        is_correct = all_good or group == self.correct_group

        self.delay.remove("pardo_hide_reveal")
        self.delay.remove("pardo_reveal_flash")

        if is_correct:
            self.round_awarding = True
            self._collect_jackpot(group)
            if self.mode_done:
                return
            self.machine.events.post("pardo_all_lights_off")
            self._start_next_round()
            return

        if self.wrong_this_round == 0:
            self._collect_first_bad_shot(group)
            return

        self.round_awarding = True
        self._collect_second_bad_shot(group)
        if self.mode_done:
            return
        self.machine.events.post("pardo_all_lights_off")
        self._start_next_round()

    def _collect_jackpot(self, group):
        self._score(self.jackpot_value)
        self.correct_shots += 1
        if self.wrong_this_round == 0:
            self.first_guess_jps += 1
        else:
            self.second_guess_jps += 1
        self.machine.events.post(
            "pardo_correct_shot",
            group=group,
            value=self.jackpot_value,
            correct_shots=self.correct_shots,
        )
        self.machine.events.post(f"pardo_correct_{group}")
        self._schedule_result_gi_restore()
        self.machine.events.post("show_mode_jackpot", message_mode_title="HYPNOSIS JACKPOT", message_mode_subtitle=group.replace("_", " ").upper(), message_mode_value=self.jackpot_value)
        self._sync_player_vars()
        if self.correct_shots >= self.CORRECT_SHOTS_TO_WIN:
            self._complete_mode()

    def _collect_first_bad_shot(self, group):
        self._score(self.BAD_SHOT_SCORE)
        self.incorrect_shots += 1
        self.wrong_this_round = 1
        self.jackpot_value = max(0, self.jackpot_value - self.jackpot_miss_penalty)
        self.current_groups.remove(group)
        self.machine.events.post(
            "pardo_incorrect_shot",
            group=group,
            incorrect_shots=self.incorrect_shots,
            round=self.round_number,
            total_rounds=self.rounds_to_play,
        )
        self.machine.events.post(f"pardo_incorrect_{group}")
        self._schedule_result_gi_restore()
        self.machine.events.post(
            "show_mode_message",
            message_mode_title="WRONG SHOT - 20,000",
            message_mode_subtitle="2 SHOTS REMAIN",
            message_mode_value=self.jackpot_value,
        )
        self._sync_player_vars()
        self._show_hidden_round()
        self._update_rooftop_diverter()

    def _collect_second_bad_shot(self, group):
        self._score(self.BAD_SHOT_SCORE)
        self.incorrect_shots += 1
        self.machine.events.post(
            "pardo_incorrect_shot",
            group=group,
            incorrect_shots=self.incorrect_shots,
            round=self.round_number,
            total_rounds=self.rounds_to_play,
        )
        self.machine.events.post(f"pardo_incorrect_{group}")
        self._schedule_result_gi_restore()
        self.machine.events.post(
            "show_mode_message",
            message_mode_title="WRONG SHOT - 20,000",
            message_mode_subtitle=f"ROUND {self.round_number} LOST",
        )
        self._sync_player_vars()

    def _reveal_current_round(self, **kwargs):
        if self._inactive() or not self.current_groups:
            return

        self.delay.remove("pardo_hide_reveal")
        self.delay.remove("pardo_reveal_flash")
        self.machine.events.post("pardo_all_lights_off")
        self.machine.events.post("show_mode_message", message_mode_title="SPINNER REVEAL", message_mode_subtitle="WATCH CLOSELY")

        all_good = self.first_round_all_good and self.round_number == 1
        for group in self.current_groups:
            if not (all_good or group == self.correct_group):
                self.machine.events.post(f"pardo_reveal_bad_{group}")

        self.reveal_flash_on = False
        self._toggle_good_reveal_flash()
        self.delay.add(
            name="pardo_hide_reveal",
            ms=self.reveal_ms,
            callback=self._show_hidden_round,
        )

    def _toggle_good_reveal_flash(self):
        if self._inactive() or not self.current_groups:
            return

        self.reveal_flash_on = not self.reveal_flash_on
        all_good = self.first_round_all_good and self.round_number == 1
        event_prefix = "pardo_reveal_good_on" if self.reveal_flash_on else "pardo_reveal_good_off"
        for group in self.current_groups:
            if all_good or group == self.correct_group:
                self.machine.events.post(f"{event_prefix}_{group}")

        self.delay.reset(
            name="pardo_reveal_flash",
            ms=self.REVEAL_FLASH_INTERVAL_MS,
            callback=self._toggle_good_reveal_flash,
        )

    def _show_hidden_round(self, **kwargs):
        self.delay.remove("pardo_reveal_flash")
        if self._inactive() or not self.current_groups:
            return

        self.machine.events.post("pardo_all_lights_off")
        for group in self.current_groups:
            self.machine.events.post(f"pardo_hidden_{group}")
        self.machine.events.post("pardo_spinner_needed")

    def _schedule_result_gi_restore(self):
        """Return the result-flash GI section to Pardo's normal GI color."""
        self.delay.reset(
            name="pardo_result_gi_restore",
            ms=self.RESULT_GI_FLASH_MS,
            callback=self._restore_result_gi,
        )

    def _restore_result_gi(self, **kwargs):
        if not self.mode_done:
            self.machine.events.post("pardo_result_gi_restore")

    def _update_rooftop_diverter(self):
        if any(group in self.UPPER_GROUPS for group in self.current_groups):
            self.machine.events.post("rooftop_diverter_open")
            self.machine.events.post("pardo_vuk_chase_start")
        else:
            self.machine.events.post("rooftop_diverter_close")
            self.machine.events.post("pardo_vuk_chase_stop")

    def _complete_mode(self, **kwargs):
        if self.mode_done:
            return
        self.mode_done = True
        player = self.machine.game.player if self.machine.game else None
        if player:
            player["pardo_state"] = 2
            player["active_mode_completed"] = 1
        self.machine.events.post("pardo_all_lights_off")
        self.machine.events.post("show_mode_message_long", message_mode_title="PARDO DEFEATED", message_mode_subtitle="HYPNOSIS BROKEN")
        self.machine.events.post("pardo_mode_complete")

    def _fail_mode(self, **kwargs):
        if self.mode_done:
            return
        self.mode_done = True
        player = self.machine.game.player if self.machine.game else None
        if player:
            player["pardo_state"] = 2
            player["active_mode_completed"] = 0
        self.machine.events.post("pardo_all_lights_off")
        self.machine.events.post("show_mode_message_long", message_mode_title="PARDO ESCAPES", message_mode_subtitle="MIND CONTROL WINS")
        self.machine.events.post("pardo_mode_complete")

    def _score(self, points):
        player = self.machine.game.player if self.machine.game else None
        if not player:
            return
        player["score"] += points
        self.mode_points += points
        self._sync_player_vars()

    def _sync_player_vars(self):
        player = self.machine.game.player if self.machine.game else None
        if not player:
            return
        player["active_mode_points"] = self.mode_points
        player["active_mode_stat_1"] = self.first_guess_jps
        player["active_mode_stat_2"] = self.second_guess_jps
        self._update_mode_status()

    def _update_mode_status(self):
        title = "CORRECT / ROUND"
        value = f"{self.correct_shots}/{self.CORRECT_SHOTS_TO_WIN} / {self.round_number}/{self.rounds_to_play}"
        self.machine.events.post("update_mode_status", mode_status_title=title, mode_status_value=value)

    def _inactive(self):
        if self.mode_done:
            return True
        if self.machine.game.player["villain_mode_in_summary"] is True:
            return True
        return False
