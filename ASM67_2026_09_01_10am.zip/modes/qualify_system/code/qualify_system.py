from mpf.core.mode import Mode


class QualifySystem(Mode):
    """Left 3-bank drops + three saucer state system.

    s_left_drops_1 -> saucer 1
    s_left_drops_2 -> saucer 2
    s_left_drops_3 -> saucer 3

    MPF bank event drop_target_bank_dt_bank_left_down marks completion.
    """

    SAUCERS = ["saucer_1", "saucer_2", "saucer_3"]
    MAX_SAUCER_STATE = 5

    def mode_start(self, **kwargs):
        super().mode_start(**kwargs)
        self.qualify_logic_active = True
        self._intel_tie_cursor = 0
        self._add_handlers()
        self._restore_state()

    def mode_stop(self, **kwargs):
        self.qualify_logic_active = False
        super().mode_stop(**kwargs)

    def _add_handlers(self):
        self.add_mode_event_handler("villain_qualify_drop_1_hit", self._drop_hit, saucer="saucer_1")
        self.add_mode_event_handler("villain_qualify_drop_2_hit", self._drop_hit, saucer="saucer_2")
        self.add_mode_event_handler("villain_qualify_drop_3_hit", self._drop_hit, saucer="saucer_3")

        # Rooftop targets act like the lower drops, but every hit advances
        # the associated saucer state. No per-bank cycle lockout.
        self.add_mode_event_handler("villain_qualify_rooftop_target_1_hit", self._rooftop_target_hit, saucer="saucer_1")
        self.add_mode_event_handler("villain_qualify_rooftop_target_2_hit", self._rooftop_target_hit, saucer="saucer_2")
        self.add_mode_event_handler("villain_qualify_rooftop_target_3_hit", self._rooftop_target_hit, saucer="saucer_3")

        self.add_mode_event_handler("drop_target_bank_dt_bank_left_down", self._bank_completed)
        self.add_mode_event_handler("saucer_star_upgrade_hit", self._star_hit)
        self.add_mode_event_handler("mystery_award_villain_start_ready", self._mystery_award_villain_start_ready)
        self.add_mode_event_handler("villain_intel_bank_completed", self._villain_intel_bank_completed)

        self.add_mode_event_handler("ball_started", self._ball_started_restore)
        self.add_mode_event_handler("villain_started_set", self._reset_after_villain)
        self.add_mode_event_handler("villain_mode_started", self._reset_after_villain)
        self.add_mode_event_handler("villain_mode_ended", self._reset_after_villain)
        self.add_mode_event_handler("chapter_mini_wizard_completed", self._reset_after_villain)
        self.add_mode_event_handler("qualify_system_restore_state", self._restore_state)

    def _ball_started_restore(self, **kwargs):
        self._reset_drop_cycle()
        self.machine.events.post("villain_qualify_drop_bank_reset_request")
        self._restore_state()

    def _qualify_blocked(self):
        player = self.machine.game.player if self.machine.game else None
        if not player:
            return True
        if player["villain_mode_running"] == 1:
            return True
        if player["chapter_mini_wizard_ready"] == 1:
            return True
        if player["final_wizard_ready"] == 1:
            return True
        return False


    def _mystery_award_villain_start_ready(self, **kwargs):
        """Daily Bugle READY VILLAIN: max all three villain-start saucers."""
        if not self.qualify_logic_active:
            return

        if self._qualify_blocked():
            self.machine.events.post("mystery_villain_start_ready_rejected", reason="progression_blocked")
            return

        player = self.machine.game.player
        extra_blocked_flags = (
            "villain_select_active",
            "chapter_select_needed",
            "chapter_select_active",
        )
        if any(self._safe_int(player[name], 0) == 1 for name in extra_blocked_flags):
            self.machine.events.post("mystery_villain_start_ready_rejected", reason="selection_active")
            return

        for saucer in self.SAUCERS:
            player[f"{saucer}_state"] = self.MAX_SAUCER_STATE
            player[f"{saucer}_drop_hit_this_cycle"] = 0
            self.machine.events.post(
                "saucer_state_advanced",
                saucer=saucer,
                state=self.MAX_SAUCER_STATE,
                source="daily_bugle_mystery",
            )
            self.machine.events.post(f"{saucer}_state_{self.MAX_SAUCER_STATE}")

        self.machine.events.post("mystery_villain_start_ready_qualified")
        self._restore_state()

    def _villain_intel_bank_completed(self, **kwargs):
        """Advance the lowest-qualified saucer after Case Files are complete."""
        if not self.qualify_logic_active:
            return

        if self._qualify_blocked():
            self.machine.events.post("villain_intel_ignored_progression_blocked")
            return

        player = self.machine.game.player
        states = {saucer: self._safe_int(player[f"{saucer}_state"], 0) for saucer in self.SAUCERS}
        eligible = [saucer for saucer in self.SAUCERS if states[saucer] < self.MAX_SAUCER_STATE]
        if not eligible:
            self.machine.events.post("villain_intel_saucers_all_maxed")
            return

        lowest_state = min(states[saucer] for saucer in eligible)
        tied = {saucer for saucer in eligible if states[saucer] == lowest_state}

        chosen = None
        for offset in range(len(self.SAUCERS)):
            index = (self._intel_tie_cursor + offset) % len(self.SAUCERS)
            candidate = self.SAUCERS[index]
            if candidate in tied:
                chosen = candidate
                self._intel_tie_cursor = (index + 1) % len(self.SAUCERS)
                break

        if chosen is None:
            return

        self._advance_saucer_state(saucer=chosen, source="villain_intel")
        new_state = self._safe_int(player[f"{chosen}_state"], 0)
        saucer_number = self.SAUCERS.index(chosen) + 1
        self.machine.events.post(
            "villain_intel_awarded",
            saucer=chosen,
            saucer_number=saucer_number,
            state=new_state,
        )
        self.machine.events.post(
            "show_mode_message",
            message_mode_title="VILLAIN INTEL +1",
            message_mode_subtitle=f"SAUCER {saucer_number}: {new_state} VILLAIN{'S' if new_state != 1 else ''}",
        )
        self._restore_state()

    def _drop_hit(self, saucer=None, **kwargs):
        if not self.qualify_logic_active or saucer not in self.SAUCERS:
            return

        player = self.machine.game.player

        if player["villain_mode_running"] == 1:
            self.machine.events.post("villain_drop_ignored_mode_running", saucer=saucer)
            return

        if player["chapter_mini_wizard_ready"] == 1:
            # Wizard readiness opens the rooftop gate immediately. Drop hits are
            # ignored here so they cannot retrigger the mechanical toggle pulse.
            self.machine.events.post(
                "villain_drop_ignored_mini_wizard_ready",
                saucer=saucer,
            )
            return

        hit_var = f"{saucer}_drop_hit_this_cycle"
        state_var = f"{saucer}_state"

        if self.machine.game.player[hit_var] == 0:
            self.machine.game.player[hit_var] = 1

            if self.machine.game.player[state_var] < self.MAX_SAUCER_STATE:
                self.machine.game.player[state_var] += 1
                self.machine.events.post(
                    "saucer_state_advanced",
                    saucer=saucer,
                    state=self.machine.game.player[state_var],
                )
                self.machine.events.post(f"{saucer}_state_{self.machine.game.player[state_var]}")
            else:
                self.machine.events.post("saucer_already_maxed", saucer=saucer)
        else:
            self.machine.events.post("drop_already_hit_this_cycle", saucer=saucer)

        self._restore_state()

    def _rooftop_target_hit(self, saucer=None, **kwargs):
        if not self.qualify_logic_active or saucer not in self.SAUCERS:
            return

        if self._qualify_blocked():
            self.machine.events.post("villain_rooftop_target_ignored_mode_running", saucer=saucer)
            return

        self._advance_saucer_state(saucer=saucer, source="rooftop_target")
        self._restore_state()

    def _advance_saucer_state(self, saucer=None, source="unknown"):
        state_var = f"{saucer}_state"

        if self.machine.game.player[state_var] < self.MAX_SAUCER_STATE:
            self.machine.game.player[state_var] += 1
            state = self.machine.game.player[state_var]
            self.machine.events.post(
                "saucer_state_advanced",
                saucer=saucer,
                state=state,
                source=source,
            )
            self.machine.events.post(f"{saucer}_state_{state}")

            if source == "rooftop_target":
                self.machine.events.post(
                    "saucer_state_advanced_by_rooftop_target",
                    saucer=saucer,
                    state=state,
                )
                self.machine.events.post(f"{saucer}_advanced_by_rooftop_target")
        else:
            self.machine.events.post("saucer_already_maxed", saucer=saucer)

    def _bank_completed(self, **kwargs):
        if not self.qualify_logic_active:
            return

        if self._qualify_blocked():
            self.machine.events.post("villain_bank_complete_ignored_mode_running")
            return

        self.machine.game.player["drop_bank_completions_this_ball"] += 1
        self.machine.game.player["drop_bank_completions_this_chapter"] += 1

        self.machine.events.post(
            "villain_qualify_drop_bank_completed",
            completions_this_ball=self.machine.game.player["drop_bank_completions_this_ball"],
            completions_this_chapter=self.machine.game.player["drop_bank_completions_this_chapter"],
        )

        self._reset_drop_cycle()
        self.machine.events.post("villain_qualify_drop_bank_reset_request")
        self._restore_state()

    def _reset_drop_cycle(self):
        for saucer in self.SAUCERS:
            self.machine.game.player[f"{saucer}_drop_hit_this_cycle"] = 0

    def _star_hit(self, **kwargs):
        if not self.qualify_logic_active:
            return

        if self._qualify_blocked():
            self.machine.events.post("villain_star_ignored_mode_running")
            return

        if not all(self.machine.game.player[f"{s}_state"] >= 1 for s in self.SAUCERS):
            self.machine.events.post("saucer_star_not_ready")
            return

        advanced = False
        for saucer in self.SAUCERS:
            state_var = f"{saucer}_state"
            if self.machine.game.player[state_var] < self.MAX_SAUCER_STATE:
                self.machine.game.player[state_var] += 1
                advanced = True
                self.machine.events.post(
                    "saucer_state_advanced_by_star",
                    saucer=saucer,
                    state=self.machine.game.player[state_var],
                )

        if advanced:
            self.machine.events.post("saucer_star_advanced_all")
        else:
            self.machine.events.post("saucers_all_maxed")

        self._restore_state()

    def _reset_after_villain(self, **kwargs):
        for saucer in self.SAUCERS:
            self.machine.game.player[f"{saucer}_state"] = 0
            self.machine.game.player[f"{saucer}_drop_hit_this_cycle"] = 0

        self.machine.game.player["drop_bank_completions_this_ball"] = 0
        self.machine.events.post("villain_qualify_reset_after_villain")
        self.machine.events.post("villain_qualify_drop_bank_reset_request")
        self._restore_state()

    def _restore_state(self, **kwargs):
        if not self.qualify_logic_active:
            return

        # Final Showdown readiness owns all three saucer lamps regardless of
        # their ordinary qualification state: any saucer starts Kingpin.
        if self._safe_int(self.machine.game.player["final_wizard_ready"], 0) == 1:
            self.machine.events.post("final_wizard_saucers_ready")
            return

        self.machine.events.post("final_wizard_saucers_clear")
        for saucer in self.SAUCERS:
            state = int(self.machine.game.player[f"{saucer}_state"])
            self.machine.events.post(
                "saucer_state_restore",
                saucer=saucer,
                state=state,
            )
            self.machine.events.post(f"{saucer}_restore_state_{state}")

    def _safe_int(self, value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default
