# main_game.tscn

Drop this file into your Godot project under:

```text
res://slides/main_game.tscn
```

It is a 1920x1080 MPF-GMC slide with anchored panels:

- P1 score: top-left
- P2 score: top-right
- Villain panel: middle-left
- Daily Bugle panel: middle-right
- Super Spinner: lower-left
- Super Pops: lower-right
- P3 score: bottom-left
- Ball count: bottom-center
- P4 score: bottom-right
- CenterVideoSafeArea: fixed 640x480 center zone

Score labels use MPFVariable with numbered player variable types and variable_name `score`.
The ball label uses the current player variable `ball`.

The center includes a hidden MPFVideoPlayer node. Assign a stream in Godot and make it visible when you want to use it, or replace it with per-mode video widgets.

Example MPF slide_player entry:

```yaml
slide_player:
  mode_base_started:
    main_game:
      action: play
```
