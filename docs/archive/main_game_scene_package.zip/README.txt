Drop slides/main_game.tscn into your Godot project under res://slides/main_game.tscn.

MPF YAML test snippet:

slide_player:
  mode_base_started:
    main_game:
      action: play
    attract:
      action: remove

This scene expects your existing MPF-GMC scripts:
- res://addons/mpf-gmc/classes/mpf_slide.gd
- res://addons/mpf-gmc/classes/mpf_variable.gd

The center Video Safe Area is fixed at 640x480 and anchored to screen center.
Temporary popup widgets should still be played through widget_player as usual.
